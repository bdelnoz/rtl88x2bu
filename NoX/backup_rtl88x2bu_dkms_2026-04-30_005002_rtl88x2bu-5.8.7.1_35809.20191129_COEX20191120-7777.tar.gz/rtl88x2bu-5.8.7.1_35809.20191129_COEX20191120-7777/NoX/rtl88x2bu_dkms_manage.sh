#!/usr/bin/env bash
# rtl88x2bu_dkms_manage.sh
# Purpose: DKMS management for local rtl88x2bu / 88x2bu driver on Kali/Debian.
# Safety: no persistent change is performed unless --exec or --reverse is explicitly passed.
# Artifacts: reports/logs/state/backups are written directly in this script directory.

set -u

VERSION="1.0.0"
SCRIPT_PATH="$(readlink -f "$0" 2>/dev/null || realpath "$0" 2>/dev/null || printf '%s\n' "$0")"
SCRIPT_DIR="$(cd "$(dirname "$SCRIPT_PATH")" && pwd -P)"
TS="$(date '+%F_%H%M%S')"
KVER="$(uname -r)"
HOST="$(hostname 2>/dev/null || true)"
USER_NAME="$(id -un 2>/dev/null || true)"
SUDO_USER_NAME="${SUDO_USER:-}"
EUID_NOW="$(id -u 2>/dev/null || echo 99999)"

MODE=""
NO_KATE=0
AP_IF="wlan1"
REPO="/mnt/data2_78g/Security/scripts/rtl88x2bu"

DKMS_NAME="rtl88x2bu"
DKMS_VERSION="5.8.7.1_35809.20191129_COEX20191120-7777"
DKMS_SRC="/usr/src/${DKMS_NAME}-${DKMS_VERSION}"
DKMS_CONF="${DKMS_SRC}/dkms.conf"

MODPROBE_CONF="/etc/modprobe.d/rtl88x2bu-local.conf"
INSTALLED_EXTRA="/lib/modules/${KVER}/extra/rtl88x2bu/88x2bu.ko"
DKMS_INSTALLED_CANDIDATE_1="/lib/modules/${KVER}/updates/dkms/88x2bu.ko"
DKMS_INSTALLED_CANDIDATE_2="/lib/modules/${KVER}/updates/dkms/88x2bu.ko.xz"

STATE_FILE="${SCRIPT_DIR}/rtl88x2bu_dkms_manage.state"
REPORT="${SCRIPT_DIR}/output4ChatGPT.${TS}.rtl88x2bu-dkms-manage.md"
LOG="${SCRIPT_DIR}/rtl88x2bu_dkms_manage.${TS}.log"

usage() {
  cat <<USAGE
Usage:
  $0 --status [--repo /path/to/repo] [--ap-if wlan1] [--no-kate]
  $0 --validation [--repo /path/to/repo] [--ap-if wlan1] [--no-kate]
  sudo $0 --exec [--repo /path/to/repo] [--ap-if wlan1] [--no-kate]
  sudo $0 --reverse [--ap-if wlan1] [--no-kate]
  $0 --help

Options:
  --status
      Read-only DKMS status report.

  --validation
      Read-only validation:
      - dkms command exists
      - active kernel headers exist
      - DKMS source tree exists
      - DKMS config exists
      - DKMS status contains rtl88x2bu/${DKMS_VERSION}
      - current kernel has DKMS-installed 88x2bu module
      - module vermagic matches active kernel
      - blacklist config exists
      - live AP interface driver is rtl88x2bu if present

  --exec
      Persistent DKMS setup:
      - backup existing /usr/src/${DKMS_NAME}-${DKMS_VERSION} if present
      - backup ${MODPROBE_CONF} if present
      - copy repository source into /usr/src/${DKMS_NAME}-${DKMS_VERSION}
      - write controlled dkms.conf
      - run dkms add/build/install for active kernel
      - write blacklist config for in-kernel rtw88 stack
      - run depmod for active kernel
      No apt action, no modprobe live-load, no insmod, no initramfs update, no service restart, no reboot.

  --reverse
      Persistent DKMS removal:
      - run dkms remove ${DKMS_NAME}/${DKMS_VERSION} --all if present
      - remove /usr/src/${DKMS_NAME}-${DKMS_VERSION}
      - restore previous source/config backups when recorded
      - run depmod for active kernel

  --repo PATH
      Source repository to copy into /usr/src for DKMS.
      Default: ${REPO}

  --ap-if IFACE
      AP interface to validate. Default: wlan1

  --no-kate
      Do not open the generated report with Kate.

Exit codes:
  0 = OK
  1 = invalid usage / general failure
  2 = validation failed
  3 = exec failed
  4 = reverse failed
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --status) MODE="status" ;;
    --validation) MODE="validation" ;;
    --exec) MODE="exec" ;;
    --reverse) MODE="reverse" ;;
    --repo)
      shift
      [ "$#" -gt 0 ] || { echo "ERROR: --repo requires a value" >&2; exit 1; }
      REPO="$1"
      ;;
    --ap-if)
      shift
      [ "$#" -gt 0 ] || { echo "ERROR: --ap-if requires a value" >&2; exit 1; }
      AP_IF="$1"
      ;;
    --no-kate) NO_KATE=1 ;;
    --help|-h) usage; exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; usage >&2; exit 1 ;;
  esac
  shift
done

[ -n "$MODE" ] || { usage; exit 1; }

need_root() {
  if [ "$EUID_NOW" != "0" ]; then
    echo "ERROR: run with sudo/root for --$MODE." >&2
    exit 1
  fi
}

open_report() {
  printf '%s\n' "$REPORT"
  if [ "$NO_KATE" -eq 0 ] && command -v kate >/dev/null 2>&1; then
    if [ "$EUID_NOW" = "0" ] && [ -n "$SUDO_USER_NAME" ] && command -v sudo >/dev/null 2>&1; then
      sudo -u "$SUDO_USER_NAME" kate "$REPORT" >/dev/null 2>&1 &
    else
      kate "$REPORT" >/dev/null 2>&1 &
    fi
  fi
}

chown_artifacts() {
  if [ -n "$SUDO_USER_NAME" ] && id "$SUDO_USER_NAME" >/dev/null 2>&1; then
    chown "$SUDO_USER_NAME:$SUDO_USER_NAME" "$REPORT" "$LOG" 2>/dev/null || true
    [ -f "$STATE_FILE" ] && chown "$SUDO_USER_NAME:$SUDO_USER_NAME" "$STATE_FILE" 2>/dev/null || true
    find "$SCRIPT_DIR" -maxdepth 1 -type f \( -name 'backup_rtl88x2bu_dkms_*' -o -name 'backup_rtl88x2bu_modprobe_*' \) -exec chown "$SUDO_USER_NAME:$SUDO_USER_NAME" {} + 2>/dev/null || true
  fi
}

append_header() {
  cat > "$REPORT" <<HDR
# rtl88x2bu DKMS manage report

- Generated at: ${TS}
- Script version: ${VERSION}
- Mode: --${MODE}
- Hostname: ${HOST}
- User: ${USER_NAME}
- SUDO_USER: ${SUDO_USER_NAME}
- EUID: ${EUID_NOW}
- Kernel: ${KVER}
- Script path: ${SCRIPT_PATH}
- Script directory: ${SCRIPT_DIR}
- Repository: ${REPO}
- DKMS name: ${DKMS_NAME}
- DKMS version: ${DKMS_VERSION}
- DKMS source: ${DKMS_SRC}
- DKMS config: ${DKMS_CONF}
- Modprobe config: ${MODPROBE_CONF}
- Existing persistent extra module path: ${INSTALLED_EXTRA}
- DKMS candidate module path 1: ${DKMS_INSTALLED_CANDIDATE_1}
- DKMS candidate module path 2: ${DKMS_INSTALLED_CANDIDATE_2}
- State file: ${STATE_FILE}
- Report: ${REPORT}
- Log: ${LOG}
- AP interface checked by validation: ${AP_IF}

## Initial verdict

**STATUS: RUNNING**

## Safety statement

This script performs read-only checks unless --exec or --reverse is explicitly used.

--exec installs/registers/builds/installs the local driver via DKMS for the active kernel.

--reverse removes this DKMS registration/install and restores recorded backups where possible.

No apt action, no DKMS package installation, no modprobe live-load, no insmod, no initramfs update, no NetworkManager setting change, no service restart, and no reboot is performed.

All reports, logs, state files, and backup copies produced by this script are written directly into the same directory as this script. No report/backup/state subfolder is created by this script.
HDR
  : > "$LOG"
}

run_block() {
  title="$1"
  shift
  {
    echo
    echo "## $title"
    echo '```text'
    echo "\$ $*"
    "$@"
    rc=$?
    echo
    echo "EXIT_CODE=$rc"
    echo '```'
  } >> "$REPORT" 2>&1
  return 0
}

write_dkms_conf() {
  cat > "$DKMS_CONF" <<'DKMSCONF'
PACKAGE_NAME="rtl88x2bu"
PACKAGE_VERSION="5.8.7.1_35809.20191129_COEX20191120-7777"
BUILT_MODULE_NAME[0]="88x2bu"
DEST_MODULE_LOCATION[0]="/updates/dkms"
AUTOINSTALL="yes"
MAKE[0]="make KVER=${kernelver}"
CLEAN="make clean"
DKMSCONF
}

write_modprobe_conf() {
  cat > "$MODPROBE_CONF" <<CONF
# Generated by ${SCRIPT_PATH} on ${TS}
# Purpose: prefer local rtl88x2bu/88x2bu DKMS driver over in-kernel rtw88_8822bu for RTL8812BU/RTL8822BU.
# Reverse with: sudo ${SCRIPT_PATH} --reverse
blacklist rtw88_8822bu
blacklist rtw88_usb
blacklist rtw88_8822b
blacklist rtw88_core
CONF
}

basic_status() {
  run_block "Required tools" bash -c "for c in dkms make gcc modinfo depmod find grep awk sed cp rm tar; do printf '%-12s' \"\$c\"; command -v \"\$c\" || true; done"
  run_block "Kernel headers path" bash -c "ls -ld '/lib/modules/$KVER' '/lib/modules/$KVER/build' 2>/dev/null || true; readlink -f '/lib/modules/$KVER/build' 2>/dev/null || true"
  run_block "DKMS status" bash -c "dkms status 2>/dev/null || true"
  run_block "DKMS source tree" bash -c "ls -ld '$DKMS_SRC' 2>/dev/null || true; ls -lh '$DKMS_SRC'/dkms.conf '$DKMS_SRC'/Makefile 2>/dev/null || true; sed -n '1,120p' '$DKMS_SRC'/dkms.conf 2>/dev/null || true"
  run_block "Current module status" bash -c "lsmod | grep -Ei '(^88x2bu|^rtl88x2bu|rtw88|8822|rtl|cfg80211|mac80211|usbcore|usb_common)' || true"
  run_block "Installed module candidates" bash -c "ls -lh '$INSTALLED_EXTRA' '$DKMS_INSTALLED_CANDIDATE_1' '$DKMS_INSTALLED_CANDIDATE_2' 2>/dev/null || true; for f in '$INSTALLED_EXTRA' '$DKMS_INSTALLED_CANDIDATE_1' '$DKMS_INSTALLED_CANDIDATE_2'; do [ -f \"\$f\" ] && { echo; echo MODINFO_FILE=\$f; modinfo \"\$f\" 2>/dev/null | sed -n '1,80p'; }; done"
  run_block "Modprobe blacklist config" bash -c "ls -lh '$MODPROBE_CONF' 2>/dev/null || true; sed -n '1,200p' '$MODPROBE_CONF' 2>/dev/null || true"
  run_block "depmod/module alias resolution" bash -c "grep -E 'usb:v2357p012D|usb:v2357p012E|usb:v0BDApB812|usb:v0BDApB82C' '/lib/modules/$KVER/modules.alias' 2>/dev/null | grep -E '88x2bu|rtl88x2bu|rtw88_8822bu' || true; echo; echo 'modprobe -n -v 88x2bu:'; modprobe -n -v 88x2bu 2>/dev/null || true; echo; echo 'modprobe -n -v rtw88_8822bu:'; modprobe -n -v rtw88_8822bu 2>/dev/null || true"
  run_block "Current AP interface binding" bash -c "ip -br link show '$AP_IF' 2>/dev/null || true; readlink -f /sys/class/net/$AP_IF/device/driver 2>/dev/null || true; cat /sys/class/net/$AP_IF/device/uevent 2>/dev/null || true"
  run_block "Script-local files" bash -c "ls -lh '$SCRIPT_DIR'/output4ChatGPT.*.rtl88x2bu-dkms-manage.md '$SCRIPT_DIR'/rtl88x2bu_dkms_manage.*.log '$SCRIPT_DIR'/rtl88x2bu_dkms_manage.state '$SCRIPT_DIR'/backup_rtl88x2bu_dkms_* '$SCRIPT_DIR'/backup_rtl88x2bu_modprobe_* 2>/dev/null || true"
}

validate_all() {
  failures=0
  {
    echo
    echo "## Important DKMS validation"
    echo
    echo "This section is read-only. It does not reload anything."
  } >> "$REPORT"

  run_block "Validation 1 - dkms command exists" bash -c "command -v dkms && echo DKMS_COMMAND_PRESENT=YES || echo DKMS_COMMAND_PRESENT=NO"
  command -v dkms >/dev/null 2>&1 || failures=$((failures + 1))

  run_block "Validation 2 - kernel headers exist" bash -c "[ -e '/lib/modules/$KVER/build' ] && echo KERNEL_HEADERS_LINK_PRESENT=YES || echo KERNEL_HEADERS_LINK_PRESENT=NO; readlink -f '/lib/modules/$KVER/build' 2>/dev/null || true"
  [ -e "/lib/modules/$KVER/build" ] || failures=$((failures + 1))

  run_block "Validation 3 - DKMS source tree and dkms.conf exist" bash -c "[ -d '$DKMS_SRC' ] && echo DKMS_SOURCE_PRESENT=YES || echo DKMS_SOURCE_PRESENT=NO; [ -f '$DKMS_CONF' ] && echo DKMS_CONF_PRESENT=YES || echo DKMS_CONF_PRESENT=NO; sed -n '1,80p' '$DKMS_CONF' 2>/dev/null || true"
  [ -d "$DKMS_SRC" ] || failures=$((failures + 1))
  [ -f "$DKMS_CONF" ] || failures=$((failures + 1))

  run_block "Validation 4 - DKMS status contains module/version" bash -c "dkms status 2>/dev/null | grep -F '${DKMS_NAME}/${DKMS_VERSION}' && echo DKMS_STATUS_ENTRY_PRESENT=YES || echo DKMS_STATUS_ENTRY_PRESENT=NO"
  dkms status 2>/dev/null | grep -F "${DKMS_NAME}/${DKMS_VERSION}" >/dev/null 2>&1 || failures=$((failures + 1))

  run_block "Validation 5 - DKMS built/installed module for active kernel" bash -c "dkms status -m '$DKMS_NAME' -v '$DKMS_VERSION' -k '$KVER' 2>/dev/null || true; dkms status 2>/dev/null | grep -F '${DKMS_NAME}/${DKMS_VERSION}' | grep -F '$KVER' || true; ls -lh '$DKMS_INSTALLED_CANDIDATE_1' '$DKMS_INSTALLED_CANDIDATE_2' 2>/dev/null || true"
  if [ ! -f "$DKMS_INSTALLED_CANDIDATE_1" ] && [ ! -f "$DKMS_INSTALLED_CANDIDATE_2" ]; then
    failures=$((failures + 1))
  fi

  run_block "Validation 6 - DKMS module vermagic matches active kernel" bash -c "f=''; [ -f '$DKMS_INSTALLED_CANDIDATE_1' ] && f='$DKMS_INSTALLED_CANDIDATE_1'; [ -z \"\$f\" ] && [ -f '$DKMS_INSTALLED_CANDIDATE_2' ] && f='$DKMS_INSTALLED_CANDIDATE_2'; echo DKMS_MODULE_FILE=\${f:-NONE}; if [ -n \"\$f\" ]; then echo MODULE_VERMAGIC=\$(modinfo -F vermagic \"\$f\" 2>/dev/null || true); vm=\$(modinfo -F vermagic \"\$f\" 2>/dev/null | awk '{print \$1}'); [ \"\$vm\" = '$KVER' ] && echo VERMAGIC_MATCH=YES || echo VERMAGIC_MATCH=NO; fi"
  f=""
  [ -f "$DKMS_INSTALLED_CANDIDATE_1" ] && f="$DKMS_INSTALLED_CANDIDATE_1"
  [ -z "$f" ] && [ -f "$DKMS_INSTALLED_CANDIDATE_2" ] && f="$DKMS_INSTALLED_CANDIDATE_2"
  if [ -n "$f" ]; then
    vm="$(modinfo -F vermagic "$f" 2>/dev/null | awk '{print $1}')"
    [ "$vm" = "$KVER" ] || failures=$((failures + 1))
  else
    failures=$((failures + 1))
  fi

  run_block "Validation 7 - modprobe blacklist config" bash -c "test -f '$MODPROBE_CONF' && echo MODPROBE_CONF_PRESENT=YES || echo MODPROBE_CONF_PRESENT=NO; grep -nE 'blacklist +(rtw88_8822bu|rtw88_usb|rtw88_8822b|rtw88_core)' '$MODPROBE_CONF' 2>/dev/null || true; for m in rtw88_8822bu rtw88_usb rtw88_8822b rtw88_core; do grep -qE \"^blacklist +\$m( |\$)\" '$MODPROBE_CONF' 2>/dev/null && echo BLACKLIST_\$m=YES || echo BLACKLIST_\$m=NO; done"
  for m in rtw88_8822bu rtw88_usb rtw88_8822b rtw88_core; do
    grep -qE "^blacklist +$m( |$)" "$MODPROBE_CONF" 2>/dev/null || failures=$((failures + 1))
  done

  run_block "Validation 8 - depmod local alias exists" bash -c "grep -E 'usb:v2357p012D.* 88x2bu' '/lib/modules/$KVER/modules.alias' 2>/dev/null && echo LOCAL_ALIAS_FOR_TPLINK_012D=YES || echo LOCAL_ALIAS_FOR_TPLINK_012D=NO"
  grep -qE 'usb:v2357p012D.* 88x2bu' "/lib/modules/$KVER/modules.alias" 2>/dev/null || failures=$((failures + 1))

  run_block "Validation 9 - live AP driver binding if AP interface exists" bash -c "if [ -e /sys/class/net/$AP_IF/device/driver ]; then echo AP_IF_PRESENT=YES; drv=\$(basename \$(readlink -f /sys/class/net/$AP_IF/device/driver 2>/dev/null)); echo AP_IF_DRIVER=\$drv; [ \"\$drv\" = 'rtl88x2bu' ] && echo AP_IF_DRIVER_EXPECTED=YES || echo AP_IF_DRIVER_EXPECTED=NO; cat /sys/class/net/$AP_IF/device/uevent 2>/dev/null || true; else echo AP_IF_PRESENT=NO; fi"
  if [ -e "/sys/class/net/$AP_IF/device/driver" ]; then
    drv="$(basename "$(readlink -f "/sys/class/net/$AP_IF/device/driver" 2>/dev/null)")"
    [ "$drv" = "rtl88x2bu" ] || failures=$((failures + 1))
  fi

  if [ "$failures" -eq 0 ]; then
    cat >> "$REPORT" <<'OKTXT'

## Final verdict

**STATUS: OK**

DKMS validation passed: dkms exists, headers exist, source tree exists, DKMS status entry exists, active-kernel DKMS module exists, vermagic matches, blacklist config exists, local alias exists, and live AP binding is correct when present.

OKTXT
    return 0
  else
    cat >> "$REPORT" <<BADTXT

## Final verdict

**STATUS: FAILED**

DKMS validation failures: ${failures}

BADTXT
    return 2
  fi
}

exec_dkms() {
  need_root
  rc=0

  {
    echo
    echo "## Pre-flight"
    echo '```text'
  } >> "$REPORT"

  if ! command -v dkms >/dev/null 2>&1; then
    echo "ERROR: dkms command not found. Install dkms from Kali repositories before using --exec." >> "$REPORT"
    rc=3
  fi
  if [ ! -e "/lib/modules/$KVER/build" ]; then
    echo "ERROR: kernel headers/build link missing: /lib/modules/$KVER/build" >> "$REPORT"
    rc=3
  fi
  if [ ! -d "$REPO" ]; then
    echo "ERROR: repository not found: $REPO" >> "$REPORT"
    rc=3
  fi
  if [ ! -f "$REPO/Makefile" ]; then
    echo "ERROR: repository Makefile not found: $REPO/Makefile" >> "$REPORT"
    rc=3
  fi
  echo "PRE_FLIGHT_RC=$rc" >> "$REPORT"
  echo '```' >> "$REPORT"

  if [ "$rc" -ne 0 ]; then
    basic_status
    return "$rc"
  fi

  {
    echo
    echo "## Backup existing DKMS source and modprobe config into script directory"
    echo '```text'
  } >> "$REPORT"

  SRC_BACKUP=""
  CONF_BACKUP=""

  if [ -d "$DKMS_SRC" ]; then
    SRC_BACKUP="${SCRIPT_DIR}/backup_rtl88x2bu_dkms_${TS}_usr_src_${DKMS_NAME}-${DKMS_VERSION}.tar.gz"
    echo "Backup DKMS source: $SRC_BACKUP" >> "$REPORT"
    tar -C "$(dirname "$DKMS_SRC")" -czf "$SRC_BACKUP" "$(basename "$DKMS_SRC")" >> "$LOG" 2>&1 || rc=3
  else
    echo "Backup DKMS source: NONE" >> "$REPORT"
  fi

  if [ -f "$MODPROBE_CONF" ]; then
    CONF_BACKUP="${SCRIPT_DIR}/backup_rtl88x2bu_modprobe_${TS}_rtl88x2bu-local.conf"
    echo "Backup modprobe config: $CONF_BACKUP" >> "$REPORT"
    cp -a "$MODPROBE_CONF" "$CONF_BACKUP" >> "$LOG" 2>&1 || rc=3
  else
    echo "Backup modprobe config: NONE" >> "$REPORT"
  fi

  {
    echo "SRC_BACKUP=$SRC_BACKUP"
    echo "CONF_BACKUP=$CONF_BACKUP"
    echo "DKMS_SRC=$DKMS_SRC"
    echo "MODPROBE_CONF=$MODPROBE_CONF"
  } > "$STATE_FILE"

  echo '```' >> "$REPORT"

  if [ "$rc" -ne 0 ]; then
    basic_status
    return "$rc"
  fi

  run_block "Remove previous DKMS registration for same module/version if present" bash -c "dkms remove -m '$DKMS_NAME' -v '$DKMS_VERSION' --all 2>/dev/null || true"

  {
    echo
    echo "## Copy repository to DKMS source tree"
    echo '```text'
    echo "rm -rf '$DKMS_SRC'"
    echo "mkdir -p '$DKMS_SRC'"
    echo "copy source from '$REPO' to '$DKMS_SRC'"
  } >> "$REPORT"

  rm -rf "$DKMS_SRC" >> "$LOG" 2>&1 || rc=3
  mkdir -p "$DKMS_SRC" >> "$LOG" 2>&1 || rc=3

  if command -v rsync >/dev/null 2>&1; then
    rsync -a --delete \
      --exclude='.git' \
      --exclude='NoX/output4ChatGPT.*' \
      --exclude='NoX/*.log' \
      --exclude='NoX/backup_rtl88x2bu_*' \
      "$REPO"/ "$DKMS_SRC"/ >> "$LOG" 2>&1 || rc=3
  else
    (cd "$REPO" && tar --exclude='./.git' --exclude='./NoX/output4ChatGPT.*' --exclude='./NoX/*.log' --exclude='./NoX/backup_rtl88x2bu_*' -cf - .) | (cd "$DKMS_SRC" && tar -xf -) >> "$LOG" 2>&1 || rc=3
  fi

  echo "COPY_RC=$rc" >> "$REPORT"
  echo '```' >> "$REPORT"

  if [ "$rc" -eq 0 ]; then
    {
      echo
      echo "## Write controlled dkms.conf"
      echo '```text'
    } >> "$REPORT"
    write_dkms_conf >> "$LOG" 2>&1 || rc=3
    sed -n '1,120p' "$DKMS_CONF" >> "$REPORT" 2>&1 || true
    echo '```' >> "$REPORT"
  fi

  if [ "$rc" -eq 0 ]; then
    {
      echo
      echo "## DKMS add"
      echo '```text'
      echo "dkms add -m '$DKMS_NAME' -v '$DKMS_VERSION'"
    } >> "$REPORT"
    if dkms add -m "$DKMS_NAME" -v "$DKMS_VERSION" >> "$REPORT" 2>&1; then
      echo >> "$REPORT"; echo "EXIT_CODE=0" >> "$REPORT"
    else
      aret=$?; echo >> "$REPORT"; echo "EXIT_CODE=$aret" >> "$REPORT"; rc=3
    fi
    echo '```' >> "$REPORT"
  fi

  if [ "$rc" -eq 0 ]; then
    {
      echo
      echo "## DKMS build active kernel"
      echo '```text'
      echo "dkms build -m '$DKMS_NAME' -v '$DKMS_VERSION' -k '$KVER'"
    } >> "$REPORT"
    if dkms build -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KVER" >> "$REPORT" 2>&1; then
      echo >> "$REPORT"; echo "EXIT_CODE=0" >> "$REPORT"
    else
      bret=$?; echo >> "$REPORT"; echo "EXIT_CODE=$bret" >> "$REPORT"; rc=3
    fi
    echo '```' >> "$REPORT"
  fi

  if [ "$rc" -eq 0 ]; then
    {
      echo
      echo "## DKMS install active kernel"
      echo '```text'
      echo "dkms install -m '$DKMS_NAME' -v '$DKMS_VERSION' -k '$KVER'"
    } >> "$REPORT"
    if dkms install -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KVER" >> "$REPORT" 2>&1; then
      echo >> "$REPORT"; echo "EXIT_CODE=0" >> "$REPORT"
    else
      iret=$?; echo >> "$REPORT"; echo "EXIT_CODE=$iret" >> "$REPORT"; rc=3
    fi
    echo '```' >> "$REPORT"
  fi

  if [ "$rc" -eq 0 ]; then
    {
      echo
      echo "## Write modprobe blacklist config"
      echo '```text'
    } >> "$REPORT"
    write_modprobe_conf >> "$LOG" 2>&1 || rc=3
    sed -n '1,200p' "$MODPROBE_CONF" >> "$REPORT" 2>&1 || true
    echo '```' >> "$REPORT"
  fi

  if [ "$rc" -eq 0 ]; then
    run_block "Run depmod for active kernel" depmod "$KVER"
    depmod "$KVER" >> "$LOG" 2>&1 || rc=3
  fi

  basic_status
  if [ "$rc" -eq 0 ]; then
    validate_all || rc=$?
  fi

  if [ "$rc" -eq 0 ]; then
    cat >> "$REPORT" <<'OKTXT'

## Final safety confirmation
```text
No apt action was performed.
No DKMS package installation was performed.
No modprobe live-load was performed.
No insmod was performed.
No initramfs was changed.
No NetworkManager setting was changed.
No service was restarted.
No reboot was requested.
DKMS persistent source/build/install was performed only because --exec was explicitly used.
```
OKTXT
  else
    cat >> "$REPORT" <<'BADTXT'

## Final safety confirmation
```text
The script attempted the requested DKMS setup, but at least one step failed.
Check the sections above before rebooting.
```
BADTXT
  fi

  return "$rc"
}

reverse_dkms() {
  need_root
  rc=0

  SRC_BACKUP=""
  CONF_BACKUP=""
  if [ -f "$STATE_FILE" ]; then
    SRC_BACKUP="$(awk -F= '/^SRC_BACKUP=/ {print $2; exit}' "$STATE_FILE" 2>/dev/null || true)"
    CONF_BACKUP="$(awk -F= '/^CONF_BACKUP=/ {print $2; exit}' "$STATE_FILE" 2>/dev/null || true)"
  fi

  {
    echo
    echo "## Reverse selected backups"
    echo '```text'
    echo "SRC_BACKUP=${SRC_BACKUP:-NONE}"
    echo "CONF_BACKUP=${CONF_BACKUP:-NONE}"
    echo '```'
  } >> "$REPORT"

  run_block "DKMS remove module/version from all kernels" bash -c "dkms remove -m '$DKMS_NAME' -v '$DKMS_VERSION' --all 2>/dev/null || true"

  {
    echo
    echo "## Remove or restore DKMS source tree"
    echo '```text'
  } >> "$REPORT"

  rm -rf "$DKMS_SRC" >> "$LOG" 2>&1 || rc=4

  if [ -n "$SRC_BACKUP" ] && [ -f "$SRC_BACKUP" ]; then
    echo "Restore DKMS source backup: $SRC_BACKUP" >> "$REPORT"
    mkdir -p "$(dirname "$DKMS_SRC")" >> "$LOG" 2>&1 || rc=4
    tar -C "$(dirname "$DKMS_SRC")" -xzf "$SRC_BACKUP" >> "$LOG" 2>&1 || rc=4
  else
    echo "No DKMS source backup restored; source tree removed." >> "$REPORT"
  fi
  echo '```' >> "$REPORT"

  {
    echo
    echo "## Restore or remove modprobe blacklist config"
    echo '```text'
  } >> "$REPORT"

  if [ -n "$CONF_BACKUP" ] && [ -f "$CONF_BACKUP" ]; then
    echo "Restore modprobe config backup: $CONF_BACKUP" >> "$REPORT"
    cp -a "$CONF_BACKUP" "$MODPROBE_CONF" >> "$LOG" 2>&1 || rc=4
  else
    if [ -f "$MODPROBE_CONF" ] && grep -qF "$SCRIPT_PATH" "$MODPROBE_CONF" 2>/dev/null; then
      echo "Remove DKMS-owned modprobe config: $MODPROBE_CONF" >> "$REPORT"
      rm -f "$MODPROBE_CONF" >> "$LOG" 2>&1 || rc=4
    else
      echo "No DKMS-owned modprobe config removed." >> "$REPORT"
    fi
  fi
  echo '```' >> "$REPORT"

  run_block "Run depmod for active kernel" depmod "$KVER"
  depmod "$KVER" >> "$LOG" 2>&1 || rc=4

  basic_status

  if [ "$rc" -eq 0 ]; then
    cat >> "$REPORT" <<'OKTXT'

## Final verdict

**STATUS: OK**

Reverse completed: DKMS module/version removed, DKMS source tree removed or restored from backup, modprobe config restored or removed when owned by this script.
OKTXT
  else
    cat >> "$REPORT" <<'BADTXT'

## Final verdict

**STATUS: FAILED**

Reverse failed partially or fully.
BADTXT
  fi

  return "$rc"
}

append_header

case "$MODE" in
  status)
    basic_status
    cat >> "$REPORT" <<'EOF2'

## Final verdict

**STATUS: OK**

Read-only DKMS status report generated.
EOF2
    rc=0
    ;;
  validation)
    basic_status
    validate_all
    rc=$?
    ;;
  exec)
    exec_dkms
    rc=$?
    ;;
  reverse)
    reverse_dkms
    rc=$?
    ;;
  *)
    echo "ERROR: invalid mode" >&2
    exit 1
    ;;
esac

chown_artifacts
open_report
exit "$rc"
